<?php $__env->startComponent('mail::message'); ?>
# Reset Password

Reset or change your password.

<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:4200/change-password?token='.$token]); ?>
Change Password
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\8vo\modasjenlp1\backend\resources\views/Email/resetPassword.blade.php ENDPATH**/ ?>